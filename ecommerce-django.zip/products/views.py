from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .models import Product, Order, OrderItem

# -------------------
# Landing Page
# -------------------
def landing(request):
    if request.user.is_authenticated:
        return redirect('product_list')
    return render(request, 'products/landing.html')


# -------------------
# Registration
# -------------------
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # after registration go to login
    else:
        form = UserCreationForm()
    return render(request, 'products/register.html', {'form': form})


# -------------------
# Product pages
# -------------------
@login_required
def product_list(request):
    products = Product.objects.all()
    return render(request, 'products/product_list.html', {'products': products})

@login_required
def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'products/product_detail.html', {'product': product})


# -------------------
# Cart
# -------------------
@login_required
def cart_detail(request):
    cart = request.session.get('cart', {})
    cart_items = []

    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)
        cart_items.append({
            'product': product,
            'quantity': quantity,
            'total_price': product.price * quantity
        })

    total = sum(item['total_price'] for item in cart_items)

    return render(request, 'products/cart.html', {
        'cart_items': cart_items,
        'total': total
    })


@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart = request.session.get('cart', {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    request.session['cart'] = cart
    return redirect('cart_detail')


@login_required
def update_cart(request):
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        for key in request.POST:
            if key.startswith("quantity_"):
                product_id = key.split("_")[1]
                qty = int(request.POST[key])
                if qty > 0:
                    cart[product_id] = qty
                else:
                    cart.pop(product_id, None)
        request.session['cart'] = cart
    return redirect('cart_detail')


@login_required
def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    cart.pop(str(product_id), None)
    request.session['cart'] = cart
    return redirect('cart_detail')


# -------------------
# Checkout
# -------------------
@login_required
def checkout(request):
    cart = request.session.get('cart', {})
    if not cart:
        return redirect('product_list')

    order = Order.objects.create(user=request.user)

    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)
        OrderItem.objects.create(order=order, product=product, quantity=quantity)

    # Clear the cart
    request.session['cart'] = {}

    return render(request, 'products/checkout_success.html', {'order': order})
